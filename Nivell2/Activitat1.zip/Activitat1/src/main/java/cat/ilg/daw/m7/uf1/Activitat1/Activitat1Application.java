package cat.ilg.daw.m7.uf1.Activitat1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Activitat1Application {

	public static void main(String[] args) {
		SpringApplication.run(Activitat1Application.class, args);
	}

}
