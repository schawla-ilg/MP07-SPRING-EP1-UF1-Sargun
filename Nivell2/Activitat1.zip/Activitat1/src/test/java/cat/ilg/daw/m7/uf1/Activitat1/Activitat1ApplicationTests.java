package cat.ilg.daw.m7.uf1.Activitat1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Activitat1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
